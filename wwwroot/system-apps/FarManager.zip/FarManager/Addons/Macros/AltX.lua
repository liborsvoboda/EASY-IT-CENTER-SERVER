Macro {
  description="Quit (F10: close editor/viewer, or exit far if in panels)";
  area="Editor Viewer Shell QView Tree Info Desktop";
  key="AltX";
  action=function()
    Keys("F10")
  end;
}
