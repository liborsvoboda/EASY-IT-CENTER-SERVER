Macro {
  description="Move to next/prev file and update panel position";
  area="Viewer";
  key="Add Subtract";
  action=function()
    Keys("AKey CtrlF10 Shift")
  end;
}
