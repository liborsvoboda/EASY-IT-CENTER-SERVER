Macro {
  description="Editor: Save File";
  area="Editor";
  key="CtrlS";
  action=function()
    Keys("F2")
  end;
}
