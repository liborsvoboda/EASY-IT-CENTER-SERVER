Macro {
  description="Ctrl+Del removes selected editor block";
  area="Editor";
  key="CtrlDel CtrlNumDel";
  flags="EVSelection";
  action=function()
    Keys("CtrlD")
  end;
}
