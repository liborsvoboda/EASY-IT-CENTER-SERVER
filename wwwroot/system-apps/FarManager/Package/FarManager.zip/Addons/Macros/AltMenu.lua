Macro {
  description="Use Alt to activate menu";
  area="Shell QView Tree Info Search";
  key="Alt RAlt";
  action=function()
    Keys("F9")
  end;
}

Macro {
  description="Use Alt to deactivate menu";
  area="MainMenu";
  key="Alt RAlt";
  action=function()
    Keys("Esc")
  end;
}
