Macro {
  description="Editor: Save File and Exit";
  area="Editor";
  key="CtrlW";
  action=function()
    Keys("ShiftF10")
  end;
}
