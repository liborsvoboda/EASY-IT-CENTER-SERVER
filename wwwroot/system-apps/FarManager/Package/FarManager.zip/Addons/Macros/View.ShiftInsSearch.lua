Macro {
  description="Use Shift+Ins to search text from clipboard in internal viewer";
  area="Viewer";
  key="ShiftIns";
  action=function()
    Keys("F7 ShiftIns Enter")
  end;
}
