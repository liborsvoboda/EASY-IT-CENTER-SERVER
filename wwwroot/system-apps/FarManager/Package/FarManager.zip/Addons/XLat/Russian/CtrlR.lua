Macro {
  area="Common"; key="CtrlR"; description="Use hotkey <Ctrl-R> to perform XLat function."; flags=""; action = function()
Keys('xlat')
  end;
}

