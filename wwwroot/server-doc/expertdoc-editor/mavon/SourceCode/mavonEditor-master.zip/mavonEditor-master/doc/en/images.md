## Example Pictures
### PC

![PC](../../img/en/en-common.png)

![PC](../../img/en/en-nav.png)

![PC](../../img/en/en-help.png)

### Link & Upload Images Gif

![PC](../../img/en/en-link.gif)

![PC](../../img/en/en-drag.gif)

![PC](../../img/en/en-image.gif)

### Mobile

![Mobile](../../img/en/en-phone.png)
&nbsp;&nbsp;&nbsp;
![Mobile](../../img/en/en-phone-nav.png)