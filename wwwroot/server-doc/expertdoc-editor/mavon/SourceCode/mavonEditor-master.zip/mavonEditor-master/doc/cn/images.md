## 图片展示

### PC

![PC](../../img/cn/cn-common.png)

![PC](../../img/cn/cn-nav.png)

![PC](../../img/cn/cn-help.png)

#### 链接 & 上传图片 Gif

![PC](../../img/cn/cn-link.gif)

![PC](../../img/cn/cn-drag.gif)

![PC](../../img/cn/cn-image.gif)

### 移动

![移动](../../img/cn/cn-phone.png)
&nbsp;&nbsp;&nbsp;
![移动](../../img/cn/cn-phone-nav.png)